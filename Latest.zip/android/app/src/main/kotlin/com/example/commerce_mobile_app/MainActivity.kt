package com.example.commerce_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
